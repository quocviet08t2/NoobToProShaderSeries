﻿#if UNITY_EDITOR
#define EDIT_MODE
//#define SHOW_DEBUG
#endif

using UnityEngine;
using System.Collections.Generic;

public enum SoundType
{
    Replace,
    New,
    Only,
    Loop
}

public enum MusicID
{
    MainMenuBgm,
    MainGameBgm1,
    MainGameBgm2,

    Count
}

public enum SoundID
{
    Countdown,  

    MainMenuButtonDrop,
    SelectGameButtonDrop,
    ButtonClick,
    SkipIntro,

	PhaoHoa,

    ShowStartList,
    HideStartList,
    StartStartList,

    ShowResultTable,
    HideResultTable,

    GetBonus,
    SelectCharacterNext,
    SelectCharacterBack,

    ButtonBack,
    ButtonLogin,
    ButtonPlay,

    // audience's sounds
    AudienceShout0,
    AudienceShout1,
    
    AudienceClap0,
    AudienceClap1,
    AudienceClap2,

    AudienceAngry0,
    AudienceAngry1,
    AudienceAngry2,
    AudienceAngry3,
    AudienceAngry4,
    AudienceAngry5,

    AudienceGibe,
    AudienceGibeLittle0,
    AudienceGibeLittle1,
    AudienceGibeLittle2,
    
    AudienceCheer0,
    AudienceCheer1,
    AudienceCheer2,

    AudienceExcited0,
    AudienceExcited1,
    AudienceExcited2,

    AudienceVeryExcited0,
    AudienceVeryExcited1,
    AudienceVeryExcited2,

    AudienceDisappointed0,
    AudienceDisappointed1,
    AudienceDisappointed2,

    AudienceShout3,

    Count
}

public class SoundManager : Singleton<SoundManager>
{
	public AudioSource[] musicSources = new AudioSource[(int)MusicID.Count];
	public AudioSource[] soundSources = new AudioSource[(int)SoundID.Count];
    
    /// <summary>
    /// The music volume.
    /// </summary>
    [Range(0, 1)]
    public float musicVolume = 1f;

    /// <summary>
    /// The sound volume.
    /// </summary>
    [Range(0, 1)]
    public float soundVolume = 1f;

    /// <summary>
    /// The lookup table for background musics.
    /// </summary>
    private Dictionary<MusicID, AudioSource> musicLookup;

    /// <summary>
    /// The lookup table for sound effects.
    /// </summary>
    private Dictionary<SoundID, AudioSource> soundLookup;

#if EDIT_MODE
    /// <summary>
    /// The lookup table for prefab background musics.
    /// </summary>
    private Dictionary<MusicID, AudioSource> prefabMusicLookup;

    /// <summary>
    /// The lookup table for prefab sound effects.
    /// </summary>
    private Dictionary<SoundID, AudioSource> prefabSoundLookup;
#endif

    /// <summary>
    /// True if enable to play background music.
    /// </summary>
    private bool isMusicEnabled = true;

    /// <summary>
    /// True if enable to play sound effect.
    /// </summary>
    private bool isSoundEnabled = true;

    // The current audio source to play music
    private AudioSource musicSource;

#if SHOW_DEBUG
	private static readonly float LabelWidth   = 70.0f;
	private static readonly float LabelHeight  = 50.0f;
	private static readonly float ButtonWidth  = 100.0f;
	private static readonly float ButtonHeight = 50.0f;

	private static readonly float Padding = 20.0f;
	private static readonly float HGap = 10.0f;
	private static readonly float VGap = 10.0f;

	void OnGUI()
	{
		float x = Padding;
		float y = Padding;

		// Music
		bool musicEnabled = GUI.Toggle(new Rect(x, y, ButtonWidth, ButtonHeight), isMusicEnabled, isMusicEnabled ? "Music On" : "Music Off");

		if (musicEnabled != isMusicEnabled)
		{
			SoundManager.Instance.MusicEnabled = musicEnabled;
		}

		x += ButtonWidth + HGap;
		
		// Sound
		bool soundEnabled = GUI.Toggle(new Rect(x, y, ButtonWidth, ButtonHeight), isSoundEnabled, isSoundEnabled ? "Sound On" : "Sound Off");
		
		if (soundEnabled != isSoundEnabled)
		{
			SoundManager.Instance.SoundEnabled = soundEnabled;
		}

		x = Padding;
		y += ButtonHeight + VGap;
		
		// Stop music
		if (GUI.Button(new Rect(x, y, ButtonWidth, ButtonHeight), "Stop music"))
		{
			SoundManager.Instance.StopMusic();
		}
		
		x += ButtonWidth + HGap;

		// Stop sound
		if (GUI.Button(new Rect(x, y, ButtonWidth, ButtonHeight), "Stop sounds"))
		{
			SoundManager.Instance.StopAllSounds();
		}

		x = Padding;
		y += ButtonHeight + VGap;
		
		// Main Game
		if (GUI.Button(new Rect(x, y, ButtonWidth, ButtonHeight), "Main Game"))
		{
			SoundManager.Instance.PlayMusic(SoundID.MainGame);
		}
		
		x += ButtonWidth + HGap;
		
		// Main Menu
		if (GUI.Button(new Rect(x, y, ButtonWidth, ButtonHeight), "Main Menu"))
		{
			SoundManager.Instance.PlayMusic(SoundID.MainMenu);
		}

		x = Padding;
		y += ButtonHeight + VGap;

		// Che gieu
		if (GUI.Button(new Rect(x, y, ButtonWidth, ButtonHeight), "Che Gieu"))
		{
			SoundManager.PlaySound(SoundID.CheGieu);
		}
		
		y += ButtonHeight + VGap;
		
		// Reo ho
		if (GUI.Button(new Rect(x, y, ButtonWidth, ButtonHeight), "Reo Ho"))
		{
			SoundManager.PlaySound(SoundID.ReoHo, SoundType.New);
			SoundManager.PlaySound(SoundID.ReoHo, SoundType.New, 1.0f);
			SoundManager.PlaySound(SoundID.ReoHo, SoundType.New, 2.0f);
		}
		
		y += ButtonHeight + VGap;
	}
#endif

    protected override void Awake()
    {
        base.Awake();
        // Create loopkup table for background musics
        musicLookup = new Dictionary<MusicID, AudioSource>();

        // Create loopkup table for sound effects
        soundLookup = new Dictionary<SoundID, AudioSource>();

#if EDIT_MODE
        // Create loopkup table for prefab background musics
        prefabMusicLookup = new Dictionary<MusicID, AudioSource>();

        // Create loopkup table for prefab sound effects
        prefabSoundLookup = new Dictionary<SoundID, AudioSource>();
#endif
        
        // Add music 
        for (int step = 0; step < musicSources.Length; step++)
        {
            AddMusic((MusicID)step, musicSources[step]);
        }

        // Add sound effects
        for (int step = 0; step < soundSources.Length; step++)
        {
            AddSound((SoundID)step, soundSources[step]);
        }
    }

    //	void LateUpdate()
    //	{
    //		foreach (AudioSource sound in soundLookup.Values)
    //		{
    //			// Check if sound enabled
    //			if (sound.enabled)
    //			{
    //				// Check if sound done
    //				if (!sound.isPlaying)
    //				{
    //					// Disable sound
    //					sound.enabled = false;
    //				}
    //			}
    //		}
    //	}

    // Change music volume
    public float MusicVolume
    {
        get
        {
            return musicVolume;
        }

        set
        {
            musicVolume = Mathf.Clamp01(value);

#if EDIT_MODE
            foreach (MusicID soundID in musicLookup.Keys)
            {
                musicLookup[soundID].volume = prefabMusicLookup[soundID].volume * musicVolume;
            }
#else
			foreach (AudioSource audioSource in musicLookup.Values)
			{
				audioSource.volume = musicVolume;
			}
#endif
        }
    }

    // Change sound volume
    public float SoundVolume
    {
        get
        {
            return soundVolume;
        }

        set
        {
            soundVolume = Mathf.Clamp01(value);

#if EDIT_MODE
            foreach (SoundID soundID in soundLookup.Keys)
            {
                soundLookup[soundID].volume = prefabSoundLookup[soundID].volume * soundVolume;
            }
#else
			foreach (AudioSource audioSource in soundLookup.Values)
			{
				audioSource.volume = soundVolume;
			}
#endif
        }
    }

    // Enable/Disable background music
    public bool MusicEnabled
    {
        get
        {
            return isMusicEnabled;
        }

        set
        {
            if (isMusicEnabled != value)
            {
                isMusicEnabled = value;

                if (isMusicEnabled)
                {
#if EDIT_MODE
                    foreach (MusicID soundID in musicLookup.Keys)
                    {
                        musicLookup[soundID].volume = prefabMusicLookup[soundID].volume * musicVolume;
                    }
#else
					foreach (AudioSource audioSource in musicLookup.Values)
					{
						audioSource.volume = musicVolume;
					}
#endif
                }
                else
                {
                    foreach (AudioSource audioSource in musicLookup.Values)
                    {
                        audioSource.volume = 0;
                    }
                }
            }
        }
    }

    // Enable/Disable sound effect
    public bool SoundEnabled
    {
        get
        {
            return isSoundEnabled;
        }

        set
        {
            if (isSoundEnabled != value)
            {
                isSoundEnabled = value;

                if (!isSoundEnabled)
                {
                    foreach (AudioSource audioSource in soundLookup.Values)
                    {
                        audioSource.enabled = false;
                    }
                }
            }
        }
    }

    public bool PlaySound(SoundID soundID, SoundType type = SoundType.Replace, float delay = 0f)
    {
        if (!isSoundEnabled) return false;

        if (!soundLookup.ContainsKey(soundID))
        {
			Debug.LogWarning(string.Format("{0} not found!", soundID.ToString()));
            return false;
        }

        // Get audio source
        AudioSource audioSource = soundLookup[soundID];

        if (audioSource != null)
        {
#if EDIT_MODE
            audioSource.Copy(prefabSoundLookup[soundID]);
#endif

            // Set enabled
            audioSource.enabled = true;

            if (type == SoundType.Loop)
            {
                audioSource.loop = true;

                if (!audioSource.isPlaying)
                {
                    if (delay > 0)
                    {
                        audioSource.PlayDelayed(delay);
                    }
                    else
                    {
                        audioSource.Play();
                    }
                }
            }
            else
            {
                audioSource.loop = false;

                if (type == SoundType.Replace)
                {
                    if (delay > 0)
                    {
                        audioSource.PlayDelayed(delay);
                    }
                    else
                    {
                        audioSource.Play();
                    }
                }
                else if (type == SoundType.New)
                {
                    audioSource.PlayOneShot(audioSource.clip);
                }
                else if (type == SoundType.Only)
                {
                    if (!audioSource.isPlaying)
                    {
                        if (delay > 0)
                        {
                            audioSource.PlayDelayed(delay);
                        }
                        else
                        {
                            audioSource.Play();
                        }
                    }
                }
            }

            return true;
        }

        return false;
    }

    public bool PlayRandomSound(params SoundID[] soundIDs)
    {
        // Get random sound ID
        SoundID soundID = soundIDs.GetRandom();

        return PlaySound(soundID);
    }

    public bool PlayRandomMusic(params MusicID[] musicIDs)
    {
        // Get random sound ID
        MusicID music = musicIDs.GetRandom();

        return PlayMusic(music);
    }

    public bool PlayMusic(MusicID soundID)
    {
        // Stop current music
        if (musicSource != null)
        {
            // Stop music
            musicSource.Stop();

            // Set disabled
            musicSource.enabled = false;
        }

        // Set music source
        musicSource = musicLookup[soundID];

        if (musicSource != null)
        {
#if EDIT_MODE
            musicSource.Copy(prefabMusicLookup[soundID]);
#endif

            // Set enabled
            musicSource.enabled = true;

            // Play music
            musicSource.Play();

            return true;
        }

        return false;
    }

    public void StopMusic()
    {
        if (musicSource != null)
        {
            // Stop music
            musicSource.Stop();

            // Set disabled
            musicSource.enabled = false;

            musicSource = null;
        }
    }

    public void StopSound(SoundID soundID)
    {
        AudioSource audioSource = soundLookup[soundID];

        if (audioSource != null)
        {
            audioSource.Stop();
            audioSource.enabled = false;
        }
    }

    public bool IsSoundFinished(SoundID soundID)
    {
        AudioSource audioSource = soundLookup[soundID];

        if (audioSource != null)
        {
            return !audioSource.isPlaying;
        }

        return true;
    }

    public void StopAllSounds()
    {
        foreach (AudioSource audioSource in soundLookup.Values)
        {
            audioSource.Stop();
            audioSource.enabled = false;
        }
    }

    void AddMusic(MusicID soundID, AudioSource audioSource)
    {
        AudioSource source = gameObject.AddComponent<AudioSource>();
        source.Copy(audioSource);
        source.enabled = false;

        musicLookup.Add(soundID, source);

#if EDIT_MODE
        prefabMusicLookup.Add(soundID, audioSource);
#endif
    }

    void AddSound(SoundID soundID, AudioSource audioSource)
    {
        AudioSource source = gameObject.AddComponent<AudioSource>();
        source.Copy(audioSource);
        source.enabled = false;

        soundLookup.Add(soundID, source);

#if EDIT_MODE
        prefabSoundLookup.Add(soundID, audioSource);
#endif
    }
}
