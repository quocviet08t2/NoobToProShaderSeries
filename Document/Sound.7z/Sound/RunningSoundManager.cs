﻿///////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2015 AsNet Co., Ltd.
// All Rights Reserved. These instructions, statements, computer
// programs, and/or related material (collectively, the "Source")
// contain unpublished information proprietary to AsNet Co., Ltd
// which is protected by US federal copyright law and by
// international treaties. This Source may NOT be disclosed to
// third parties, or be copied or duplicated, in whole or in
// part, without the written consent of AsNet Co., Ltd.
///////////////////////////////////////////////////////////////////////////////

using UnityEngine;

namespace Running
{
    public enum RunningMusicID
    {
		BGM1,
		BGM2,

        Count
    }

    public enum RunningSoundID
    {
        // Sound effects
        StartRun,
        FinishGame,

        // player Sounds
        PlayerMissing0,
        PlayerMissing1,
        PlayerMissing2,
        
        // Effect bonus
        Tomato1,
        Tomato2,
        Tomato3,

        // Voice
        VoicePerfect,        
        VoicePerfectStreak,
        VoiceGreat,
        VoiceGood,

        // Sound tap
        TapTrung,
        TapTrat,        
        TapPerfect,
        PerfectStreak,

        // hurdles
        PlayerJump1,
        PlayerJump2,
        PlayerJump3,
        
        JumpOnHurdle1,
        JumpOnHurdle2,
        JumpOnHurdle3,

        HurdleFall1,
		HurdleFall2,

		HurdleCombo,
        HurdleFinsihCombo,
        FinishJump,

        OnYourMark,
        SetReady,

        Count
    }

    public class RunningSoundManager : BaseSoundManager
    {
		public AudioSource[] musicSources = new AudioSource[(int)RunningMusicID.Count];
		public AudioSource[] soundSources = new AudioSource[(int)RunningSoundID.Count];

        protected override void Awake()
        {
            base.Awake();
            
			AddSources(musicSources, soundSources);
        }

		public static bool PlayMusic(RunningMusicID musicId)
        {
			return _instance.PlayMusic((int)musicId);
        }

		public static bool PlaySound(RunningSoundID soundID, SoundType type = SoundType.New, float delay = 0f)
        {
			return _instance.PlaySound((int)soundID, type, delay);
        }

		public static bool PlayRandomSound(params RunningSoundID[] soundIDs)
        {
			return _instance.PlaySound((int)soundIDs.GetRandom());
		}

		public static bool PlayRandomSound(SoundType type, float delay, params RunningSoundID[] soundIDs)
		{
			return _instance.PlaySound((int)soundIDs.GetRandom(), type, delay);
		}

		public static void StopAll()
		{
			_instance.StopAllSounds();
		}

		public override string GetMusicName(int musicID)
		{
			return ((RunningMusicID)musicID).ToString();
		}

		public override string GetSoundName(int soundID)
		{
			return ((RunningSoundID)soundID).ToString();
		}

		public override int GetMusicCount()
		{
			return (int)RunningMusicID.Count;
		}

		public override int GetSoundCount()
		{
			return (int)RunningSoundID.Count;
		}
    }
}
