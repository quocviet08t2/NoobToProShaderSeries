﻿///////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2015 AsNet Co., Ltd.
// All Rights Reserved. These instructions, statements, computer
// programs, and/or related material (collectively, the "Source")
// contain unpublished information proprietary to AsNet Co., Ltd
// which is protected by US federal copyright law and by
// international treaties. This Source may NOT be disclosed to
// third parties, or be copied or duplicated, in whole or in
// part, without the written consent of AsNet Co., Ltd.
///////////////////////////////////////////////////////////////////////////////

using UnityEngine;

namespace Shooting
{
    public enum ShootingMusicID
    {
        BGM1,
        BGM2,

        Count
    }

    public enum ShootingSoundID
    {
        // shooting
        Pull,
        Round_1,
        Round_2,
        Round_3,
        Shooting,
        Skeet_Break,
        Cheering,
        Lare,
        Skeet_Throw,
        GunReload,
        PhaoHoa,
        BirdFly,
        BirdBeingHit,

		// Voice
		Good,
		Great,
		Awesome,
		Unbelievable,
		Incredible,

		BirdFly1,
		BirdFly2,
		BirdSing1,
		BirdSing2,
		BirdSing3,
		BirdSing4,

		BonusRound,

        Count
    }

    public class ShootingSoundManager : BaseSoundManager
    {
		public AudioSource[] musicSources = new AudioSource[(int)ShootingMusicID.Count];
		public AudioSource[] soundSources = new AudioSource[(int)ShootingSoundID.Count];

        protected override void Awake()
        {
            base.Awake();
            
			AddSources(musicSources, soundSources);
        }

		public static bool PlayMusic(ShootingMusicID musicId)
        {
			return _instance.PlayMusic((int)musicId);
        }

		public static bool PlaySound(ShootingSoundID soundID, SoundType type = SoundType.Replace, float delay = 0f)
        {
			return _instance.PlaySound((int)soundID, type, delay);
        }

		public static void StopSound(ShootingSoundID soundID)
        {
			_instance.StopSound((int)soundID);
        }

		public static void StopAll()
		{
			_instance.StopAllSounds();
		}

		public static bool IsSoundFinished(ShootingSoundID soundID)
        {
			return _instance.IsSoundFinished((int)soundID);
		}

		public override string GetMusicName(int musicID)
		{
			return ((ShootingMusicID)musicID).ToString();
		}

		public override string GetSoundName(int soundID)
		{
			return ((ShootingSoundID)soundID).ToString();
		}

		public override int GetMusicCount()
		{
			return (int)ShootingMusicID.Count;
		}

		public override int GetSoundCount()
		{
			return (int)ShootingSoundID.Count;
		}
    }
}
