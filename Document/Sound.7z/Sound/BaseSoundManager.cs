﻿///////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2015 AsNet Co., Ltd.
// All Rights Reserved. These instructions, statements, computer
// programs, and/or related material (collectively, the "Source")
// contain unpublished information proprietary to AsNet Co., Ltd
// which is protected by US federal copyright law and by
// international treaties. This Source may NOT be disclosed to
// third parties, or be copied or duplicated, in whole or in
// part, without the written consent of AsNet Co., Ltd.
///////////////////////////////////////////////////////////////////////////////

#if UNITY_EDITOR
#define EDIT_MODE
#endif

using System;
using UnityEngine;
using System.Collections.Generic;

public class BaseSoundManager : MonoBehaviour
{
	#region Singleton

	protected static BaseSoundManager _instance;

	public static BaseSoundManager Instance
	{
		get
		{
			return _instance;
		}
	}

	public BaseSoundManager()
	{
		_instance = this;
	}

	#endregion

	/// <summary>
	/// The lookup table for background musics.
	/// </summary>
	private Dictionary<int, AudioSource> _musicLookup;

	/// <summary>
	/// The lookup table for sound effects.
	/// </summary>
	private Dictionary<int, AudioSource> _soundLookup;

#if EDIT_MODE
	/// <summary>
	/// The lookup table for prefab background musics.
	/// </summary>
	private Dictionary<int, AudioSource> prefabMusicLookup;
	
	/// <summary>
	/// The lookup table for prefab sound effects.
	/// </summary>
	private Dictionary<int, AudioSource> prefabSoundLookup;
#endif

	/// <summary>
	/// True if enable to play background music.
	/// </summary>
	private bool _isMusicEnabled = true;

	/// <summary>
	/// True if enable to play sound effect.
	/// </summary>
	private bool _isSoundEnabled = true;

	// The current audio source to play music
	private AudioSource _musicSource;

	protected virtual void Awake()
	{
		// Create loopkup table for background musics
		_musicLookup = new Dictionary<int, AudioSource>();
		
		// Create loopkup table for sound effects
		_soundLookup = new Dictionary<int, AudioSource>();

#if EDIT_MODE
		// Create loopkup table for prefab background musics
		prefabMusicLookup = new Dictionary<int, AudioSource>();
		
		// Create loopkup table for prefab sound effects
		prefabSoundLookup = new Dictionary<int, AudioSource>();
#endif
    }

	protected void AddSources(AudioSource[] musicSources, AudioSource[] soundSources)
	{
		for (int i = 0; i < musicSources.Length; i++)
		{
			AddMusic(i, musicSources[i]);
		}

		for (int i = 0; i < soundSources.Length; i++)
		{
			AddSound(i, soundSources[i]);
		}
	}

//	void LateUpdate()
//	{
//		foreach (AudioSource sound in _soundLookup.Values)
//		{
//			// Check if sound enabled
//			if (sound.enabled)
//			{
//				// Check if sound done
//				if (!sound.isPlaying)
//				{
//					// Disable sound
//					sound.enabled = false;
//				}
//			}
//		}
//	}

	// Enable/Disable background music
	public bool MusicEnabled
	{
		get
		{
			return _isMusicEnabled;
		}

		set
		{
			if (_isMusicEnabled != value)
			{
				_isMusicEnabled = value;

				if (_isMusicEnabled)
				{
#if EDIT_MODE
					foreach (int soundID in _musicLookup.Keys)
					{
						_musicLookup[soundID].volume = prefabMusicLookup[soundID].volume;
					}
#else
					foreach (AudioSource audioSource in _musicLookup.Values)
					{
						audioSource.volume = 1.0f;
					}
#endif
				}
				else
				{
					foreach (AudioSource audioSource in _musicLookup.Values)
					{
						audioSource.volume = 0;
					}
				}
			}
		}
	}

	// Enable/Disable sound effect
	public bool SoundEnabled
	{
		get
		{
			return _isSoundEnabled;
		}

		set
		{
			if (_isSoundEnabled != value)
			{
				_isSoundEnabled = value;

				if (!_isSoundEnabled)
				{
					foreach (AudioSource audioSource in _soundLookup.Values)
					{
						audioSource.enabled = false;
					}
				}
			}
		}
	}

	// Play music
	public bool PlayMusic(int soundID)
	{
		// Stop current music
		if (_musicSource != null)
		{
			// Stop music
			_musicSource.Stop();
			
			// Set disabled
			_musicSource.enabled = false;
		}
		
		// Set music source
		_musicSource = _musicLookup[soundID];
		
		if (_musicSource != null)
		{
#if EDIT_MODE
			_musicSource.Copy(prefabMusicLookup[soundID]);
#endif
			
			// Set enabled
			_musicSource.enabled = true;
			
			// Play music
			_musicSource.Play();
			
			return true;
		}
		
		return false;
	}

	// Stop music
	public void StopMusic()
	{
		if (_musicSource != null)
		{
			// Stop music
			_musicSource.Stop();
			
			// Set disabled
			_musicSource.enabled = false;
			
			_musicSource = null;
		}
	}

	// Play sound
	public bool PlaySound(int soundID, SoundType type = SoundType.Replace, float delay = 0f)
	{
		if (!_isSoundEnabled) return false;

		if (!_soundLookup.ContainsKey(soundID))
		{
			Debug.LogWarning(string.Format("{0} not found!", GetSoundName(soundID)));
			return false;
		}

		// Get audio source
		AudioSource audioSource = _soundLookup[soundID];

		if (audioSource != null)
		{
#if EDIT_MODE
			audioSource.Copy(prefabSoundLookup[soundID]);
#endif

			// Set enabled
			audioSource.enabled = true;

			if (type == SoundType.Loop)
			{
				audioSource.loop = true;

				if (!audioSource.isPlaying)
				{
					if (delay > 0)
					{
						audioSource.PlayDelayed(delay);
					}
					else
					{
						audioSource.Play();                        
                    }
				}
			}
			else
			{
				audioSource.loop = false;

				if (type == SoundType.Replace)
				{
					if (delay > 0)
					{
						audioSource.PlayDelayed(delay);
					}
					else
					{
						audioSource.Play();
					}
				}
				else if (type == SoundType.New)
				{
					audioSource.PlayOneShot(audioSource.clip);
				}
				else if (type == SoundType.Only)
				{
					if (!audioSource.isPlaying)
					{
						if (delay > 0)
						{
							audioSource.PlayDelayed(delay);
						}
						else
						{
							audioSource.Play();
						}
					}
				}
			}

			return true;
		}

		return false;
	}

	public bool IsSoundFinished(int soundID)
	{
		AudioSource audioSource = _soundLookup[soundID];
		
		if (audioSource != null)
		{
			return !audioSource.isPlaying;
		}
		
		return true;
	}

	public void StopSound(int soundID)
    {
        AudioSource audioSource = _soundLookup[soundID];

        if (audioSource != null)
        {
            audioSource.Stop();
            audioSource.enabled = false;
        }
    }

	public void StopAllSounds()
	{
		foreach (AudioSource audioSource in _soundLookup.Values)
		{
			audioSource.Stop();
			audioSource.enabled = false;
		}
	}

	public virtual string GetMusicName(int musicID)
	{
		return musicID.ToString();
	}

	public virtual string GetSoundName(int soundID)
	{
		return soundID.ToString();
	}

	public virtual int GetMusicCount()
	{
		return 0;
	}

	public virtual int GetSoundCount()
	{
		return 0;
	}

	protected virtual void AddMusic(int soundID, AudioSource audioSource)
	{
		AudioSource source = gameObject.AddComponent<AudioSource>();
		source.Copy(audioSource);
		source.enabled = false;

		_musicLookup.Add(soundID, source);

#if EDIT_MODE
		prefabMusicLookup.Add(soundID, audioSource);
#endif
	}

	protected virtual void AddSound(int soundID, AudioSource audioSource)
	{
		AudioSource source = gameObject.AddComponent<AudioSource>();
		source.Copy(audioSource);
		source.enabled = false;

		_soundLookup.Add(soundID, source);

#if EDIT_MODE
		prefabSoundLookup.Add(soundID, audioSource);
#endif
	}
}
